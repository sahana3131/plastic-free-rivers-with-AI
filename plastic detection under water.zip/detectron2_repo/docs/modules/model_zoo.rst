detectron2.model_zoo package
============================

.. automodule:: detectron2.model_zoo
    :members:
    :undoc-members:
    :show-inheritance:
