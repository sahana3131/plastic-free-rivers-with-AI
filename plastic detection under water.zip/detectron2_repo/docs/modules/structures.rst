detectron2.structures package
=============================

.. automodule:: detectron2.structures
    :members:
    :undoc-members:
    :show-inheritance:
